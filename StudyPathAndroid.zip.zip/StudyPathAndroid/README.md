# StudyPath Android App

This is a native Android WebView wrapper for the StudyPath HTML app.

- App name: StudyPath
- Persistent data: HTML localStorage inside the app's WebView storage
- No browser is required to run the app
- Internet permission is included because the current HTML loads PDF.js from a CDN
- GitHub Actions workflow builds a debug APK in the cloud

## Phone-only build
1. Create a GitHub repository named `StudyPath`.
2. Upload all files/folders from this project.
3. Open the **Actions** tab.
4. Run **Build StudyPath APK** using **Run workflow**.
5. When it finishes, open the workflow run and download the **StudyPath-APK** artifact.
6. Extract the artifact and install `app-debug.apk` on Android.
